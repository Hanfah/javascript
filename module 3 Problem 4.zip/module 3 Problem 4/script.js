



const students = {
	name:"Ruth",
	age:45
}


function checkKey(object){
	const hasKey = 'name' in students;

	if(hasKey){
		document.write("key exists");
	} else{
		document.write("key does not exist")
	}

