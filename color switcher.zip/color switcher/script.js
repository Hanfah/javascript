function changeBackground(y){
	var body = document.getElementById("body");
	body.style.backgroundColor=y.value;

}